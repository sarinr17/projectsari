<div class="container">
    <?= form_open_multipart();?>
       <div class="row">
            <div class="col">
                <label for="formFile" class="form-label">Foto</label>
            </div>
       </div>
       <div class="row">
            <div class="col-sm-3">
                <div class="mb-3">
                    <img src="<?= base_url('assets/foto/') . $peminjam['foto']; ?>" id="formFile" class="img-thumbnail" width="225" height="330">
                    <input class="form-control" type="file" id="formFile" name="image" value="<?= $peminjam['foto']; ?>" style="width : 500px;" require>
                    <div class="form-text text-danger"><?= form_error('image'); ?></div>
                </div>
            </div>
    </div>
    <div class="mb-3">
        <label for="nama" class="form-label">Nama</label>
        <input type="text" class="form-control" id="nama" name="nama" value="<?= $peminjam['nama']; ?>" style="width : 500px;">
        <div class="form-text text-danger"><?= form_error('nama'); ?></div>
    </div>
    <div class="mb-3">
        <label for="alamat" class="form-label">Alamat</label>
        <input type="text" class="form-control" id="alamat" name="alamat" value="<?= $peminjam['alamat']; ?>" style="width : 500px;">
        <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
    </div>
    <div class="mb-3">
       <label for="no_hp" class="form-label">No_hp</label>
        <input type="text" class="form-control" id="no_hp" name="no_hp" value="<?= $peminjam['no_hp']; ?>" style="width : 500px;">
        <div class="form-text text-danger"><?= form_error('no_hp'); ?></div>
    </div>
    <div class="mb-3">
        <label for="barang" class="form-label">barang</label>
        <select class="form-select" id="barang" name="barang" name="barang" style="width :500px;">
            <option selected value="<?= $peminjam['id_barang']; ?>"><?= $peminjam['barang']; ?></option>
        <?php foreach( $barang as $bar ) : ?>
            <option value="<?= $bar['id']; ?>"><?= $bar['barang']; ?></option>
        <?php endforeach; ?>
    </select>
    <div class="form-tetx text-danger"><?= form_error('barang'); ?></div>
    </div>
    <div class="mb-3">
       <label for="keperluan" class="form-label">Keperluan</label>
        <input type="text" class="form-control" id="keperluan" name="keperluan" value="<?= $peminjam['keperluan']; ?>" style="width : 500px;">
        <div class="form-text text-danger"><?= form_error('keperluan'); ?></div>
    </div>
    <input type="submit" value="submit" class="btn btn-primary"></input>
</form>
</div>

