<div class="container">
    <?= form_open_multipart('peminjam/tambah');?>
        <legend>Tambah Data peminjam</legend>
        <div class="mb-3">
            <label for="formFile" class="form-label">Foto</label>
            <input class="form-control" type="file" id="formFile" name="image" style="width : 500px;" require>
            <div class="form-text text-danger"><?= form_error('image'); ?></div>
        </div>
        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
            <label for="angkatan" class="form-label">Alamat</label>
            <input type="text" class="form-control" id="alamat" name="alamat" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
        </div>
        <div class="mb-3">
            <label for="no_hp" class="form-label">No_hp</label>
            <input type="text" class="form-control" id="no_hp" name="no_hp" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('no_hp'); ?></div>
        </div>
        <div class="mb-3">
        <label for="barang" class="form-label">pilih barang</label>
        <select class="form-select" id="barang" name="barang" style="width : 500px;">
                <option selected>Pilih Barang</option>
            <?php foreach( $barang as $bar) : ?>
                <option value="<?= $bar['id']; ?>"><?= $bar['barang']; ?></option>
            <?php endforeach; ?>
            </select>
            <div class="form-text text-danger"><?= form_error('barang'); ?></div>
        </div>
        <div class="mb-3">
            <label for="keperluan" class="form-label">Keperluan</label>
            <textarea class="form-control" id="keperluan" name="keperluan" style="width : 500px;"></textarea>
            <div class="form-text text-danger"><?= form_error('keperluan'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>

