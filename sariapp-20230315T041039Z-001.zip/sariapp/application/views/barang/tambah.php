<div class="container">
    <form action="" method="post">
        <legend>Tambah Data Barang</legend>
        <div class="mb-3">
            <label for="barang" class="form-label">Nama Barang</label>
            <input type="text" class="form-control" id="barang" name="barang" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('barang'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>